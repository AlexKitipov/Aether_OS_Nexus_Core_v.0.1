#![no_std]
#![no_main]

extern crate alloc;

use core::panic::PanicInfo;
use alloc::vec::Vec;
use alloc::collections::BTreeMap;
use alloc::format;

use smoltcp::iface::{Config, Interface, SocketSet, QueryInterface};
use smoltcp::phy::Checksum;
use smoltcp::socket::{TcpSocket, UdpSocket, Socket};
use smoltcp::wire::{EthernetAddress, HardwareAddress, IpAddress, IpCidr, Ipv4Address, ETHERNET_MTU};
use smoltcp::time::Instant;

use crate::ipc::vnode::VNodeChannel;
use crate::syscall::{syscall2, syscall3, SYS_LOG, SUCCESS, E_ERROR, SYS_TIME, SYS_NET_ALLOC_BUF, SYS_NET_FREE_BUF, SYS_NET_TX, SYS_NET_RX_POLL, SYS_GET_DMA_BUF_PTR, SYS_SET_DMA_BUF_LEN};

mod aethernet_device;
use aethernet_device::AetherNetDevice;

// Temporary log function for V-Nodes
fn log(msg: &str) {
    unsafe {
        let res = syscall3(
            SYS_LOG,
            msg.as_ptr() as u64,
            msg.len() as u64,
            0 // arg3 is unused for SYS_LOG
        );
        if res != SUCCESS { /* Handle log error, maybe panic or fall back */ }
    }
}

// Get current time from kernel
fn get_current_time_ms() -> u64 {
    // Assuming SYS_TIME returns ticks, convert to ms for smoltcp Instant
    unsafe { syscall2(SYS_TIME, 0, 0) * 10 } // Assuming 1 tick = 10 ms for demo
}

// Temporary syscall for allocating a DMA buffer
fn net_alloc_buf(size: usize) -> Result<u64, u64> {
    unsafe {
        let handle = syscall2(SYS_NET_ALLOC_BUF, size as u64, 0);
        if handle == E_ERROR || handle == E_ACC_DENIED { Err(handle) } else { Ok(handle) }
    }
}

// Temporary syscall for freeing a DMA buffer
fn net_free_buf(handle: u64) -> Result<(), u64> {
    unsafe {
        let res = syscall2(SYS_NET_FREE_BUF, handle, 0);
        if res != SUCCESS { Err(res) } else { Ok(()) }
    }
}

// Temporary syscall for transmitting a network packet
fn net_tx(iface_id: u64, buf_handle: u64, len: u64) -> Result<(), u64> {
    unsafe {
        let res = syscall3(SYS_NET_TX, iface_id, buf_handle, len);
        if res != SUCCESS { Err(res) } else { Ok(()) }
    }
}

// Temporary syscall to get pointer to DMA buffer
fn get_dma_buffer_ptr(handle: u64) -> Result<*mut u8, u64> {
    unsafe {
        let ptr = syscall2(SYS_GET_DMA_BUF_PTR, handle, 0);
        if ptr == E_ERROR || ptr == E_ACC_DENIED { Err(ptr) } else { Ok(ptr as *mut u8) }
    }
}

// Temporary syscall to set DMA buffer length
fn set_dma_buffer_len(handle: u64, len: usize) -> Result<(), u64> {
    unsafe {
        let res = syscall2(SYS_SET_DMA_BUF_LEN, handle, len as u64);
        if res != SUCCESS { Err(res) } else { Ok(()) }
    }
}


// --- IPC API for other V-Nodes (Socket API) ---
// (Simplified for sketch, actual would use postcard serialization)
#[derive(Debug, serde::Serialize, serde::Deserialize)]
enum NetStackRequest {
    OpenSocket(u32), // TCP/UDP, port
    Send(u32, Vec<u8>), // socket_handle, data
    Recv(u32), // socket_handle
    CloseSocket(u32), // socket_handle
}

#[derive(Debug, serde::Serialize, serde::Deserialize)]
enum NetStackResponse {
    SocketOpened(u32), // socket_handle
    Data(Vec<u8>),
    Error(u32), // error_code
    Success,
}

#[no_mangle]
pub extern "C" fn _start() -> ! {
    // For simplicity, hardcode channel ID for aethernet-service
    let mut own_chan = VNodeChannel::new(3); // Channel to receive requests from other V-Nodes
    let net_bridge_channel_id = 2; // Channel to communicate with net-bridge

    log("AetherNet Service V-Node starting up...");

    // Allocate a DMA buffer for the AetherNetDevice to use for RX (it's managed by the kernel)
    let rx_dma_handle = match net_alloc_buf(ETHERNET_MTU as usize) {
        Ok(h) => {
            log("AetherNet: Allocated RX DMA buffer for device.");
            h
        },
        Err(e) => {
            log(&alloc::format!("AetherNet: Failed to allocate RX DMA buffer for device: {}", e));
            loop { /* ... */ }
        }
    };

    // 1. Initialize AetherNetDevice to interact with the net-bridge driver
    // Pass the pre-allocated RX buffer handle
    let mut device = AetherNetDevice::new(0, rx_dma_handle);

    // 2. Configure smoltcp interface
    let ethernet_addr = EthernetAddress([0x02, 0x00, 0x00, 0x00, 0x00, 0x01]);
    let config = Config::new(HardwareAddress::Ethernet(ethernet_addr));
    let mut iface = Interface::new(config, &mut device, Instant::from_millis(get_current_time_ms()));

    // Assign a static IP address
    iface.update_ip_addrs(|addrs| {
        addrs.push(IpCidr::new(IpAddress::v4(10, 0, 2, 15), 24)).unwrap();
    });
    log(&alloc::format!("AetherNet: IP Address set to {}", IpAddress::v4(10,0,2,15)));

    // 3. Initialize smoltcp SocketSet
    let mut sockets = SocketSet::new(Vec::new());

    // 4. Socket Management
    let mut next_socket_handle: u32 = 1;
    let mut smoltcp_sockets_map: BTreeMap<u32, smoltcp::socket::SocketHandle> = BTreeMap::new(); // Maps our handle to smoltcp's

    // Main event loop for the network stack
    loop {
        let timestamp = Instant::from_millis(get_current_time_ms());

        // 1. Poll smoltcp interface for network events (e.g., ARP, ICMP, TCP/UDP activity)
        // This call will trigger device.receive() and device.transmit() internally
        iface.poll(timestamp, &mut device, &mut sockets);

        // 2. Process incoming requests from other V-Nodes (Socket API)
        // Use a non-blocking receive to ensure smoltcp polling is not starved
        if let Ok(Some(req_data)) = own_chan.recv_non_blocking() { // Assuming recv_non_blocking exists
            if let Ok(request) = postcard::from_bytes::<NetStackRequest>(&req_data) {
                log("AetherNet: Received request from another V-Node.");
                let response = match request {
                    NetStackRequest::OpenSocket(port) => {
                        log(&alloc::format!("AetherNet: Opening socket on port {}", port));
                        // Here, smoltcp would be used to open a socket
                        NetStackResponse::SocketOpened(port + 1000) // Simulate new handle
                    },
                    NetStackRequest::Send(handle, data) => {
                        log(&alloc::format!("AetherNet: Sending {} bytes on socket {}", data.len(), handle));
                        // Here, smoltcp would be used to send data
                        NetStackResponse::Success
                    },
                    NetStackRequest::Recv(handle) => {
                        log(&alloc::format!("AetherNet: Receiving on socket {}", handle));
                        // Here, smoltcp would be used to receive data
                        NetStackResponse::Data(Vec::new()) // Simulate empty data
                    },
                    NetStackRequest::CloseSocket(handle) => {
                        log(&alloc::format!("AetherNet: Closing socket {}", handle));
                        // Here, smoltcp would be used to close a socket
                        NetStackResponse::Success
                    },
                };
                own_chan.send(&response).unwrap_or_else(|_| log("AetherNet: Failed to send response."));
            } else {
                log("AetherNet: Failed to deserialize NetStackRequest.");
            }
        }
    }
}

#[panic_handler]
pub extern "C" fn panic(_info: &PanicInfo) -> ! {
    log("AetherNet Service V-Node panicked!");
    loop {}
}
