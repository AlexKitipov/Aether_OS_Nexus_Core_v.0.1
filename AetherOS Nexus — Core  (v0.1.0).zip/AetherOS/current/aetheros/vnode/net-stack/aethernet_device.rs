#![no_std]

extern crate alloc;

use alloc::vec::Vec;
use smoltcp::phy::{Device, RxToken, TxToken, Checksum, DeviceCapabilities};
use smoltcp::time::Instant;
use smoltcp::wire::{EthernetAddress, HardwareAddress};

use crate::ipc::vnode::VNodeChannel;
use crate::syscall::{syscall3, SYS_LOG, SUCCESS, E_ERROR, SYS_NET_ALLOC_BUF, SYS_NET_FREE_BUF, SYS_NET_TX, SYS_NET_RX_POLL, get_dma_buffer_ptr};

// Temporary log function for V-Nodes
fn log(msg: &str) {
    unsafe {
        let res = syscall3(
            SYS_LOG,
            msg.as_ptr() as u64,
            msg.len() as u64,
            0 // arg3 is unused for SYS_LOG
        );
        if res != SUCCESS { /* Handle log error, maybe panic or fall back */ }
    }
}

// Temporary syscall for allocating a DMA buffer
fn net_alloc_buf(size: usize) -> Result<u64, u64> {
    unsafe {
        let handle = syscall2(SYS_NET_ALLOC_BUF, size as u64, 0);
        if handle == E_ERROR { Err(handle) } else { Ok(handle) }
    }
}

// Temporary syscall for freeing a DMA buffer
fn net_free_buf(handle: u64) -> Result<(), u64> {
    unsafe {
        let res = syscall2(SYS_NET_FREE_BUF, handle, 0);
        if res != SUCCESS { Err(res) } else { Ok(()) }
    }
}

// Temporary syscall for transmitting a network packet
fn net_tx(iface_id: u64, buf_handle: u64, len: u64) -> Result<(), u64> {
    unsafe {
        let res = syscall3(SYS_NET_TX, iface_id, buf_handle, len);
        if res != SUCCESS { Err(res) } else { Ok(()) }
    }
}

// Temporary syscall to get pointer to DMA buffer
fn get_dma_buffer_ptr(handle: u64) -> Option<*mut u8> {
    unsafe {
        let ptr = syscall2(SYS_GET_DMA_BUF_PTR, handle, 0);
        if ptr == E_ERROR { None } else { Some(ptr as *mut u8) }
    }
}

/// Represents a single received packet buffer for smoltcp.
pub struct PacketRxToken<'a> {
    buffer: &'a mut [u8],
    dma_handle: u64,
}

impl<'a> RxToken for PacketRxToken<'a> {
    fn consume<R, F>(self, _timestamp: Instant, f: F) -> R
    where
        F: FnOnce(&mut [u8]) -> R,
    {
        // The smoltcp stack consumes the packet data
        let result = f(self.buffer);
        // After consumption, free the DMA buffer
        if let Err(e) = net_free_buf(self.dma_handle) {
            log(&alloc::format!("AetherNetDevice: Failed to free RX DMA buffer: {}", e));
        }
        result
    }
}

/// Represents a single transmitted packet buffer for smoltcp.
pub struct PacketTxToken<'a> {
    buffer: &'a mut [u8],
    dma_handle: u64,
    len: usize,
    iface_id: u64,
    net_bridge_chan: VNodeChannel, // Channel to net-bridge V-Node
}

impl<'a> TxToken for PacketTxToken<'a> {
    fn consume<R, F>(self, _timestamp: Instant, f: F) -> R
    where
        F: FnOnce(&mut [u8]) -> R,
    {
        let result = f(self.buffer);
        // After smoltcp fills the buffer, transmit it
        if let Err(e) = net_tx(self.iface_id, self.dma_handle, self.len as u64) {
            log(&alloc::format!("AetherNetDevice: Failed to transmit packet: {}", e));
        }
        // Free the DMA buffer after transmission
        if let Err(e) = net_free_buf(self.dma_handle) {
            log(&alloc::format!("AetherNetDevice: Failed to free TX DMA buffer: {}", e));
        }
        result
    }
}

/// AetherNetDevice implements smoltcp::phy::Device for communication with net-bridge V-Node.
pub struct AetherNetDevice {
    iface_id: u64, // Interface ID, typically 0 for the first NIC
    bridge_chan: VNodeChannel, // Channel to net-bridge for control/notifications if needed
}

impl AetherNetDevice {
    pub fn new(iface_id: u64, channel_id: u32) -> Self {
        AetherNetDevice {
            iface_id,
            bridge_chan: VNodeChannel::new(channel_id),
        }
    }
}

impl<'a> Device<'a> for AetherNetDevice {
    type RxToken = PacketRxToken<'a>;
    type TxToken = PacketTxToken<'a>;

    fn capabilities(&self) -> DeviceCapabilities {
        let mut caps = DeviceCapabilities::default();
        caps.max_transmission_unit = 1500;
        caps.max_burst_size = Some(1);
        caps.checksum = Checksum::None;
        caps.medium = smoltcp::phy::Medium::Ethernet;
        caps
    }

    fn receive(&'a mut self, _timestamp: Instant) -> Option<(Self::RxToken, Self::TxToken)> {
        // Allocate a DMA buffer for incoming packet
        let dma_handle = match net_alloc_buf(1536) {
            Ok(h) => h,
            Err(e) => { log(&alloc::format!("AetherNetDevice: Failed to alloc RX DMA buffer: {}", e)); return None; }
        };

        // Poll the kernel for a received packet
        let len = unsafe {
            syscall3(
                SYS_NET_RX_POLL,
                self.iface_id, // Interface ID
                dma_handle, // DMA handle where kernel should copy data
                1536 as u64 // Max buffer length
            )
        };

        if len > SUCCESS { // len > 0 indicates a packet was received
            if let Some(buf_ptr) = get_dma_buffer_ptr(dma_handle) {
                let buffer = unsafe { core::slice::from_raw_parts_mut(buf_ptr, len as usize) };
                // For smoltcp, we must return both RxToken and an optional TxToken.
                // In many cases, we don't immediately transmit on receive, so TxToken can be None.
                // For simplicity, we just return the RxToken here.
                Some((PacketRxToken { buffer, dma_handle }, PacketTxToken {
                    buffer: &mut [], // dummy buffer
                    dma_handle: 0,
                    len: 0,
                    iface_id: self.iface_id,
                    net_bridge_chan: VNodeChannel::new(self.bridge_chan.id) // Pass a clone of the channel
                }))
            } else {
                log("AetherNetDevice: Failed to get buffer pointer for RX DMA handle.");
                if let Err(e) = net_free_buf(dma_handle) { log(&alloc::format!("AetherNetDevice: Failed to free RX DMA buffer (ptr error): {}", e)); }
                None
            }
        } else if len == SUCCESS { // No packet or spurious IRQ
             // Free the unused buffer immediately if no packet was received
             if let Err(e) = net_free_buf(dma_handle) { log(&alloc::format!("AetherNetDevice: Failed to free unused RX DMA buffer: {}", e)); }
            None
        } else { // Error from syscall
            log(&alloc::format!("AetherNetDevice: SYS_NET_RX_POLL returned error code: {}", len));
             if let Err(e) = net_free_buf(dma_handle) { log(&alloc::format!("AetherNetDevice: Failed to free RX DMA buffer (syscall error): {}", e)); }
            None
        }
    }

    fn transmit(&'a mut self, _timestamp: Instant) -> Option<Self::TxToken> {
        // Allocate a DMA buffer for outgoing packet
        let dma_handle = match net_alloc_buf(1536) {
            Ok(h) => h,
            Err(e) => { log(&alloc::format!("AetherNetDevice: Failed to alloc TX DMA buffer: {}", e)); return None; }
        };

        if let Some(buf_ptr) = get_dma_buffer_ptr(dma_handle) {
            let buffer = unsafe { core::slice::from_raw_parts_mut(buf_ptr, 1536) }; // Max MTU
            Some(PacketTxToken { buffer, dma_handle, len: 1536, iface_id: self.iface_id, net_bridge_chan: VNodeChannel::new(self.bridge_chan.id) })
        } else {
            log("AetherNetDevice: Failed to get buffer pointer for TX DMA handle.");
            if let Err(e) = net_free_buf(dma_handle) { log(&alloc::format!("AetherNetDevice: Failed to free TX DMA buffer (ptr error): {}", e)); }
            None
        }
    }
}
'''
